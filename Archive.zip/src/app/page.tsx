import AppWrapper from '@/components/AppWrapper';

export default function Home() {
  return <AppWrapper />;
}